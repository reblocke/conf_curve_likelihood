# Ticket 08 — Future extensibility for selection rules and teaching workflows

## Goal

Prepare a roadmap or optional implementation for extending design calibration beyond the MVP two-sided `p < alpha` rule.

This ticket should not be mixed into the MVP unless Tickets 01-07 are stable.

## Potential selection rules

Add a selection-rule abstraction that can later support:

1. `two_sided_p_lt_alpha`
   - MVP rule; equivalent to CI excluding the null under symmetric Wald assumptions.

2. `one_sided_positive_p_lt_alpha`
   - Claim selection when only positive/beneficial direction is considered.

3. `one_sided_negative_p_lt_alpha`
   - Claim selection when only negative/harmful direction is considered.

4. `ci_excludes_null_in_beneficial_direction`
   - Similar to one-sided claim but framed as CI decision.

5. `estimate_exceeds_mcid_and_p_lt_alpha`
   - Claim-worthy result requires both statistical selection and observed estimate beyond a clinical threshold.

6. `ci_excludes_mcid`
   - Stronger clinical claim rule; useful for noninferiority/superiority teaching but requires careful wording.

## Architecture recommendation

Create a small selection-rule interface in `src/confcurve/design.py`:

```python
@dataclass(frozen=True)
class SelectionRuleSpec:
    key: str
    label: str
    alpha: float
    direction: Literal["two_sided", "positive", "negative", "custom"]
    threshold_working: float | None = None
```

Each rule should provide:

```python
selection_probability(delta: float) -> float
wrong_sign_probability(delta: float) -> float | None
expected_abs_z_selected(delta: float) -> float | None
```

For complex rules such as “estimate exceeds MCID and p < alpha,” analytic expressions may be more involved. Use exact normal interval/tail calculations when possible; otherwise use deterministic numerical integration with tests.

## UI cautions

Selection-rule labels must say what claim is being selected, not just the statistical test. Example:

```text
Claim rule: selected if two-sided p < alpha against the null
```

For clinical-threshold claim rules, add:

```text
This rule changes which results count as selected claims. Type S/M values are conditional on that claim rule.
```

## Teaching examples

Add optional built-in examples or a docs tutorial:

1. **Small noisy trial**: large observed effect, high Type M at MCID.
2. **Precise null-compatible trial**: nonsignificant but low compatibility with large effects.
3. **Ratio measure**: Type M on log scale, natural-scale asymmetry.
4. **Negative/harm direction**: symmetric Type S/M behavior on working scale.

## URL/state persistence

Consider adding design fields to shareable URL state if the app already supports or later adds URL persistence. Do not implement persistence if no URL-state pattern exists yet.

## Accessibility and copy polish

Future visual improvements:

- aria labels for metric selector and copy buttons,
- table captions that explain design-conditioned quantities,
- keyboard-accessible tooltips or equivalent summary text,
- print-friendly one-page handout export.

## Acceptance criteria for roadmap-only version

- Add a documented roadmap under `docs/TYPE_SM_DESIGN_ANALYSIS.md` or a separate ADR.
- Do not expose non-MVP selection rules in UI unless tested.
- Existing MVP behavior remains unchanged.

## Acceptance criteria for implementation version

- Each new selection rule has analytic/numerical tests.
- UI labels make the claim rule explicit.
- Scenario table and reviewer text include the selected claim rule.
- E2E tests cover changing the rule and invalid threshold configurations.
