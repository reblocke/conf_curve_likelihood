# Ticket 01 — Add numerical core for Type S / Type M design metrics

## Goal

Add a tested Python numerical module that computes design operating characteristics across candidate true effect sizes under the app's existing one-parameter Wald model.

This ticket should not change the browser UI. It should create a reusable numerical core that later tickets can expose through `compute_curves()` and the static web app.

## Files likely involved

- Add: `src/confcurve/design.py`
- Update: `src/confcurve/__init__.py` if public exports are appropriate
- Update: `src/confcurve/models.py` if TypedDicts or Literals are useful now
- Add tests: `tests/test_design_metrics.py` or similar

Do not edit staged browser Python under `web/assets/py/confcurve/` by hand. Staging is handled in later verification with `make stage-web`.

## Statistical specification

Work on the **working scale**.

Let:

```text
eta_true = candidate true effect on working scale
eta_null = null value on working scale
se       = reconstructed working-scale standard error
alpha    = two-sided significance threshold
c        = Normal quantile z_(1 - alpha / 2)
delta    = (eta_true - eta_null) / se
Z        = (future estimate - eta_null) / se ~ Normal(delta, 1)
selection event = {|Z| > c}
```

### Power

```text
upper_tail = P(Z > c)  = sf(c - delta)
lower_tail = P(Z < -c) = cdf(-c - delta)
power = upper_tail + lower_tail
```

At `delta = 0`, power should equal `alpha` up to numerical tolerance.

### Type S probability

Type S is the conditional probability that a selected/significant estimate has the wrong sign relative to the true effect direction.

```text
if delta > 0: TypeS = lower_tail / power
if delta < 0: TypeS = upper_tail / power
if abs(delta) <= near_null_delta: TypeS = None  # sign is undefined at null
```

Do not return `0.5` at exactly null in the API unless the UI explicitly labels it as “coin-flip sign, not wrong sign.” For this app, return `None` near the null and let renderers display “undefined at null.”

### Type M exaggeration ratio

Type M is the expected magnitude exaggeration among selected/significant estimates:

```text
TypeM = E(|Z| | |Z| > c) / |delta|
```

Use the exact truncated-normal expression rather than simulation:

```text
upper_tail = sf(c - delta)
lower_tail = cdf(-c - delta)
power = upper_tail + lower_tail
selected_abs_numerator = delta * (upper_tail - lower_tail) + phi(c - delta) + phi(-c - delta)
expected_selected_abs_z = selected_abs_numerator / power
TypeM = expected_selected_abs_z / abs(delta)
```

If `abs(delta) <= near_null_delta`, return `None` for Type M.

### Observed exaggeration if candidate were true

When an observed/current estimate is available:

```text
observed_exaggeration = abs(eta_hat - eta_null) / abs(eta_true - eta_null)
```

Return `None` near the null.

This is not Type M. It is a retrospective comparison between the observed estimate and a hypothesized true effect.

## Proposed API

Implement something close to this, adapting to repo style:

```python
from dataclasses import dataclass
from typing import Literal

SelectionRule = Literal["two_sided_p_lt_alpha"]

@dataclass(frozen=True)
class DesignMetric:
    true_effect_working: float
    delta: float
    power: float
    type_s: float | None
    type_m: float | None
    expected_selected_abs_z: float | None
    observed_exaggeration: float | None


def design_metrics_for_true_effects(
    true_effects_working: np.ndarray,
    *,
    null_working: float,
    se: float,
    estimate_working: float | None = None,
    alpha: float = 0.05,
    selection_rule: SelectionRule = "two_sided_p_lt_alpha",
    near_null_delta: float = 1e-12,
) -> list[DesignMetric]:
    ...
```

A vectorized internal implementation is preferred, but the public return value must be JSON-safe after conversion in later tickets.

## Validation rules

Raise the repo's existing `ValidationError` or a compatible error when:

- `se <= 0`
- `alpha <= 0` or `alpha >= 1`
- true effects, null, or estimate are non-finite
- unsupported selection rule is requested
- `near_null_delta < 0`

## Unit tests

Add deterministic tests for:

1. **Power at null**: `delta = 0` gives `power ≈ alpha`.
2. **Symmetry**: power and Type M are identical for `delta = +d` and `delta = -d`; Type S is symmetric as well.
3. **Wrong-sign tails**: for `delta > 0`, Type S uses the lower tail; for `delta < 0`, Type S uses the upper tail.
4. **High-power behavior**: for large `abs(delta)`, Type S approaches 0 and Type M approaches 1.
5. **Near-null handling**: Type S, Type M, and observed exaggeration are `None` when `abs(delta) <= near_null_delta`.
6. **Simulation sanity check**: for a few fixed deltas, compare analytic power/Type S/Type M against a seeded Monte Carlo approximation with loose tolerances. Mark this as a normal unit test only if it is fast and stable; otherwise keep deterministic analytic tests.
7. **Input validation**: invalid alpha, SE, and non-finite values raise errors.

## Acceptance criteria

- New module imports without circular dependencies.
- Existing tests still pass.
- New tests cover formulas and edge cases.
- No browser behavior changes yet.
- No `NaN`/`Infinity` assumptions leak into future JSON-facing data structures.

## Scientific wording to preserve in comments/docstrings

Use wording like:

> These are design operating characteristics for repeated studies under an assumed true effect and Wald SE. They are not posterior probabilities about the observed estimate.
