# Ticket 03 — Add UI controls and state plumbing for design calibration

## Goal

Add a browser UI section that lets users enable Type S / Type M design calibration and pass design-analysis inputs to the Python `compute_curves()` contract.

This ticket should not require final polished visualization. It should make the design payload reachable from the app state and visibly summarize whether design calibration is enabled.

## Dependencies

Requires Tickets 01-02.

## Files likely involved

- `web/index.html`
- `web/assets/app.js`
- `web/assets/config.js`
- `web/assets/formatters.js`
- `web/assets/renderers.js`
- E2E tests under `tests/e2e/`

## UI controls

Add a new fieldset/card below existing curve controls:

### Label

```text
Design calibration: Type S / Type M risk
```

### Controls

1. Checkbox: `Enable design calibration`
   - Default: unchecked for MVP.
   - When unchecked, send `design_enabled: false` and hide or collapse detailed design controls.

2. Alpha input/select:
   - Label: `Selection threshold alpha`
   - Default: `0.05`
   - Valid range: `0 < alpha < 1`
   - Use for two-sided `p < alpha` selection.

3. Selection rule display:
   - Label: `Selection rule`
   - MVP: disabled select or static text: `Two-sided p < alpha against the null`
   - Value sent: `two_sided_p_lt_alpha`

4. Custom assumed true effects input:
   - Label: `Assumed true effects / MCIDs`
   - Placeholder examples:
     - additive: `0.10, 0.20, 0.30`
     - ratio: `0.80, 1.20, 1.50`
   - Values are on display scale.
   - Parse similarly to existing thresholds parsing.

5. Optional plausible true-effect range:
   - Label: `Plausible true-effect range for design interpretation`
   - Lower and upper numeric fields, display scale.
   - MVP behavior: pass through as metadata; do not change observed x-grid.

## Payload construction

Update the browser request builder to include:

```js
{
  design_enabled: boolean,
  design_alpha: number,
  design_selection_rule: "two_sided_p_lt_alpha",
  design_true_effects: number[],
  design_plausible_range_lower: number | null,
  design_plausible_range_upper: number | null
}
```

Keep existing observed-curve payload keys unchanged.

## User-facing explanatory copy

Add a short help block near the controls:

```text
Design calibration treats each x-axis value as a possible true effect. It asks: if that value were true and a study had this SE, how often would statistically selected claims be wrong-sign or exaggerated? These are repeated-study operating characteristics, not posterior probabilities about the observed result.
```

Add a ratio-scale caveat when relevant:

```text
For ratio measures, Type M is computed on the log scale away from the null ratio of 1.
```

Add near-null caveat:

```text
Type M is undefined at or very near the null because the true effect denominator is zero.
```

## Validation behavior

- If alpha is invalid, show a user-facing validation error and do not compute.
- If true-effect values are invalid for the selected effect type, rely on Python validation and display the returned error using existing error handling.
- For ratio effects, nonpositive assumed true-effect values should be rejected.
- If only one plausible range bound is supplied, show/propagate a validation error.

## Minimal rendering for this ticket

Before Ticket 04, add a simple text summary in the existing summary area when design is enabled:

```text
Design calibration enabled: alpha = 0.05, selection rule = two-sided p < alpha.
```

If response includes warnings under `response.design.warnings`, render them with existing warnings.

## E2E tests

Add tests that:

1. Design controls are present but collapsed/disabled when the checkbox is off.
2. Enabling design calibration sends a design-enabled payload and renders the minimal summary.
3. Invalid alpha shows an error and does not silently compute.
4. Ratio-effect negative assumed true effect fails validation.
5. Disabling design returns the app to the pre-existing behavior.

## Acceptance criteria

- App loads with design disabled by default.
- Existing examples still render exactly as before unless design is enabled.
- Design-enabled payload reaches Pyodide and returns without errors for valid inputs.
- User-facing copy distinguishes observed-data compatibility from design operating characteristics.
