# Ticket 04 — Add design-risk visualization panel across candidate true effects

## Goal

Add a coordinated visualization that plots design operating characteristics across candidate true effects on the same x-axis as the observed confidence/likelihood curve.

The recommended MVP is a separate design panel below the existing plot, with a metric selector. A risk ribbon inside the existing plot is a stretch goal.

## Dependencies

Requires Tickets 01-03.

## Files likely involved

- `web/assets/plot.js`
- `web/assets/plot-helpers.js`
- `web/assets/renderers.js`
- `web/assets/app.js`
- `web/assets/styles.css`
- Playwright tests under `tests/e2e/`

## Visualization semantics

The x-axis value has two meanings depending on panel:

- Observed-evidence panel: “How compatible is this value with the observed data?”
- Design-risk panel: “If this value were the true effect, how reliable would significant claims be?”

This distinction must appear in labels/tooltips or panel subtitles.

## MVP design panel

Add a design panel below the existing plot when `response.design` is enabled.

### Metric selector

Add a selector with options:

```text
Power
Type S probability
Type M exaggeration
Observed exaggeration if true
```

Default metric: `Type M exaggeration` or `Power`. Prefer `Power` if the y-axis scaling for Type M is not yet polished.

### Traces

Use `response.design.grid.true_effect_display` for x-values and the selected design metric for y-values.

- Skip/leave gaps for `null` values.
- Label undefined near-null Type M/Type S values clearly in hover text.
- For Type S and Power, y-axis should be probability from 0 to 1.
- For Type M and observed exaggeration, use a ratio axis. Consider capping or warning for extreme values rather than letting one near-null point flatten the entire plot.

### Reference markers

Show vertical reference markers for:

- null value,
- CI-implied estimate,
- CI bounds,
- user thresholds/MCIDs when available.

Reuse existing marker/label helpers where possible.

### Plausible true-effect range

If `design_plausible_range_lower` and upper are supplied and valid, show a light shaded band or bracket in the design panel only. This range should not change the observed curve.

## Hover tooltip content

For each candidate true effect, hover should include:

```text
Candidate true effect: [display value]
Observed compatibility p-value at this value: [existing p-curve value]
Relative likelihood vs estimate: [existing likelihood value]
If this value were true:
  Power: [x]
  Type S: [x or undefined]
  Type M: [x or undefined]
  Observed exaggeration: [x or undefined]
```

Keep formatting compact.

## Optional risk ribbon stretch goal

If the design panel is stable, add a thin risk ribbon under the main x-axis or under the design panel. It should classify the selected metric using configurable thresholds:

- Power: low `<0.5`, moderate `0.5-0.8`, adequate `>=0.8`.
- Type S: low `<0.01`, caution `0.01-0.05`, high `>0.05`.
- Type M: low `<1.25`, caution `1.25-2`, high `>2`.

Do not make the ribbon the only visualization; it should be an interpretive aid.

## Exports

- Dashboard PNG export should include the design panel when enabled.
- Manuscript figure export can either include design panel or remain observed-curve-only, but behavior must be explicit in the caption and documentation.
- Copyable caption should mention design calibration when included.

## E2E tests

Add tests that:

1. Enabling design displays a design panel.
2. Metric selector changes the plotted metric.
3. Type M/observed exaggeration show gaps or undefined labels near null rather than crashing.
4. Ratio effect example uses natural x-axis labels but design Type M note says log scale.
5. PNG export still succeeds when design panel is visible.

## Acceptance criteria

- Existing plot modes still work with design disabled.
- Design panel shares/coheres with the existing x-axis scale.
- The UI does not imply Type S/M are observed-data probabilities.
- Undefined near-null values are handled gracefully.
- Browser E2E tests pass.
