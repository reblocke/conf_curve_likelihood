# Ticket 06 — Add precision scenarios and inverse design targets

## Goal

Let users ask how Type S/M and power would change if the study had more or less information, and estimate the SE/information required to meet design targets at a clinically meaningful assumed true effect.

This ticket is optional for MVP but highly valuable for grant critiques and sample-size discussions.

## Dependencies

Requires Tickets 01-05.

## Files likely involved

- `src/confcurve/design.py`
- `src/confcurve/web_contract.py`
- `src/confcurve/models.py`
- `web/index.html`
- `web/assets/app.js`
- `web/assets/renderers.js`
- `web/assets/formatters.js`
- tests under `tests/` and `tests/e2e/`

## Precision scenario input

Add a design-only precision control:

```text
Information multiplier
```

Default: `1.0`.

Interpretation:

```text
se_design = se_current / sqrt(information_multiplier)
```

Examples:

- `1x`: current CI-implied precision.
- `2x`: twice the information, SE divided by sqrt(2).
- `4x`: four times the information, SE halved.

Important: this affects only design metrics. It must not alter the observed confidence curve, observed relative-likelihood curve, observed p-value curve, or CI reconstruction.

## Payload additions

Add to design config/request:

```python
design_information_multiplier: float  # > 0, default 1.0
```

Return in design config:

```python
current_se_working: float
design_se_working: float
information_multiplier: float
current_ci_width_working: float
approx_design_ci_width_working: float
```

For natural ratio measures, optionally show approximate natural-scale widths only as descriptive examples; the authoritative width should be working-scale.

## Inverse design target calculations

Add functions in `design.py` to solve for required SE or information multiplier at a specified true effect.

Suggested public functions:

```python
def solve_required_delta_for_power(alpha: float, target_power: float) -> float: ...
def solve_required_delta_for_type_s(alpha: float, max_type_s: float) -> float: ...
def solve_required_delta_for_type_m(alpha: float, max_type_m: float) -> float: ...

def solve_required_precision(
    true_effect_working: float,
    *,
    null_working: float,
    current_se: float,
    alpha: float = 0.05,
    target_power: float | None = None,
    max_type_s: float | None = None,
    max_type_m: float | None = None,
) -> dict[str, float | None]: ...
```

Use monotonic bisection on `abs(delta)` rather than closed-form approximations. Avoid infinite loops and return `None` with warning when no finite solution is meaningful, especially when the assumed true effect is at/near null.

For a required standardized distance `delta_required`:

```text
required_se = abs(true_effect_working - null_working) / delta_required
required_information_multiplier = (current_se / required_se)^2
approx_95_ci_width_working = 2 * z_0.975 * required_se
```

## UI inputs for inverse design

Add a compact “Precision target” subsection:

- Select true-effect scenario to target: custom value/MCID/threshold.
- Target power, default `0.80`.
- Maximum Type S, default optional blank or `0.01`.
- Maximum Type M, default optional blank or `1.25`.

Render a table:

```text
Target
Required SE
Required 95% CI width, working scale
Required information multiplier vs current
Notes
```

## Tests

Add numerical tests:

1. Information multiplier changes design power/typeM but not observed summary SE.
2. `4x` information approximately halves design SE.
3. Required power target returns a smaller required SE than current when current power is below target.
4. Required Type M target behaves monotonically: stricter Type M target requires larger information multiplier.
5. Near-null target returns no finite meaningful precision and a warning.
6. Invalid target values raise validation errors.

Add E2E tests:

1. Changing information multiplier updates design scenario table values.
2. Observed CI/likelihood summaries do not change when information multiplier changes.
3. Precision target table renders and copy text remains valid.

## Acceptance criteria

- Precision scenarios are clearly labeled as hypothetical design scenarios.
- Existing observed-data displays are unchanged by information multiplier.
- Required precision calculations are stable and tested.
- User-facing text explains that information multipliers are approximate one-parameter Wald information scaling.
