# Ticket 07 — Strengthen tests, documentation, and verification for Type S / Type M features

## Goal

Finalize the Type S/M design-calibration feature with robust scientific tests, browser tests, documentation, and decision records.

## Dependencies

Requires whichever implementation tickets have been completed. At minimum, apply after Tickets 01-05.

## Files likely involved

- `README.md`
- `docs/DECISIONS.md`
- Add: `docs/TYPE_SM_DESIGN_ANALYSIS.md`
- Possibly add: `docs/adr/YYYY-MM-DD-type-sm-design-calibration.md`
- `tests/`
- `tests/e2e/`
- `CITATION.cff` only if release metadata changes

## Documentation requirements

### README update

Add a concise section under “What the app does”:

```text
Optionally computes design-calibration quantities—power, Type S wrong-sign probability, Type M magnitude exaggeration, and observed exaggeration—across candidate assumed true effects using the CI-implied Wald SE and a two-sided p < alpha selection rule.
```

Add to “What the app does not do”:

```text
It does not treat Type S/M as posterior probabilities that the observed estimate is wrong. Type S/M are repeated-study operating characteristics under user-specified assumed true effects and a selected claim rule.
```

Add ratio-scale caveat:

```text
For ratio measures, Type M is computed on the log working scale.
```

### New docs page

Create `docs/TYPE_SM_DESIGN_ANALYSIS.md` with these sections:

1. **Purpose** — why Type S/M complements confidence and likelihood curves.
2. **Model** — one-parameter normal/Wald model, working scale, null, SE, alpha.
3. **Formulas** — power, Type S, Type M, observed exaggeration.
4. **Interpretation** — design-conditioned vs observed-data-conditioned quantities.
5. **Ratio-scale handling** — log scale for odds/risk/hazard ratios.
6. **Undefined values near null** — why Type M and Type S are blank/undefined.
7. **Reviewer wording** — short copy examples.
8. **Limitations** — no exact fitted likelihood, no posterior probability, no substitute for external effect-size justification.

### Decision record

Update `docs/DECISIONS.md` or add an ADR documenting:

- why Type S/M lives in the Python numerical core,
- why MVP supports only two-sided `p < alpha`,
- why Type M is computed on working scale,
- why undefined near-null values return null/blank,
- why design ranges do not alter observed curve reconstruction.

## Test hardening

Ensure the suite covers:

### Python numerical tests

- analytic formula correctness,
- symmetry,
- high-power asymptotics,
- near-null handling,
- ratio log-scale behavior,
- JSON-safety of payloads.

### Contract tests

- design disabled response,
- design enabled response,
- invalid alpha,
- invalid ratio true effects,
- scenario deduplication,
- CSV schema.

### Browser E2E tests

- UI loads with design disabled,
- enabling design shows controls and design panel/table,
- metric selector works,
- scenario reviewer text copy block appears,
- invalid inputs display errors,
- export still works.

## Scientific validation checklist

Add or enforce a test/comment checklist that explicitly verifies:

- Type S/M are functions of assumed true effect, not observed p-value alone.
- Observed p-value curve and design metrics can disagree without contradiction.
- Information multiplier, if implemented, affects only design metrics.
- Existing observed curve examples are unchanged when design is disabled.

## Verification commands

Run:

```bash
uv sync --locked
make stage-web
make fmt-check
make lint
make test
make e2e
make verify
```

If Playwright browsers are missing:

```bash
uv run playwright install chromium webkit
```

## Acceptance criteria

- Documentation clearly separates observed-evidence and design-reliability layers.
- All implemented Type S/M features have unit and E2E coverage.
- `make verify` passes.
- Final PR summary includes remaining limitations and any intentionally deferred future selection rules.
