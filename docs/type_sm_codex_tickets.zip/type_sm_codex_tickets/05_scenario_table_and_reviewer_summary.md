# Ticket 05 — Add design scenario table and reviewer-ready summary text

## Goal

Provide a compact table and copyable prose summarizing design reliability at clinically meaningful assumed true effects: MCIDs, thresholds, external/prior plausible effects, and the CI-implied estimate as an explicitly labeled optimistic scenario.

## Dependencies

Requires Tickets 01-04.

## Files likely involved

- `src/confcurve/web_contract.py`
- `src/confcurve/models.py`
- `web/assets/renderers.js`
- `web/assets/formatters.js`
- `web/assets/styles.css`
- tests under `tests/` and `tests/e2e/`

## Scenario sources

Populate `response.design.scenarios` with rows for:

1. `null`
   - Label: `Null`
   - Note: `Type S/M undefined at null; power equals alpha under the point null.`

2. `ci_implied_estimate`
   - Label: `CI-implied estimate as truth`
   - Note: `Optimistic/circular: uses the observed estimate as the assumed true effect.`

3. Existing clinical/reference thresholds
   - Source: `threshold`
   - Label: `Threshold: [value]`
   - These can double as MCIDs when users enter clinically meaningful thresholds.

4. Custom assumed true effects from the new design input
   - Source: `custom_true_effect`
   - Label: `Assumed true effect: [value]`

Deduplicate rows within a tight working-scale tolerance to avoid repeating the same null/estimate/threshold.

## Scenario table columns

Render a table with:

```text
Assumed true effect
Source / note
Delta vs null (SE units)
Power at alpha
Type S among selected claims
Type M exaggeration among selected claims
Observed exaggeration if this value were true
```

Optional if already available:

```text
Expected selected |estimate-null| / SE
```

## Formatting rules

- Probabilities as percentages with sensible precision.
- Type M and observed exaggeration as `x` ratios, e.g. `2.4x`.
- Undefined values: `—` plus tooltip or small note.
- For ratio measures, add note: `Type M is computed on the log scale.`
- For the CI-implied estimate-as-truth row, visibly label it as optimistic/circular.

## Reviewer-ready summary text

Add a copyable text block generated from a selected scenario row. Default selected scenario should be:

1. first custom assumed true effect if provided,
2. otherwise first threshold not equal to null,
3. otherwise CI-implied estimate-as-truth with an optimistic-scenario warning.

Suggested text:

```text
Using the CI-implied Wald standard error and assuming a true effect of [X], this design would have [POWER]% power for a two-sided alpha of [ALPHA]. Conditional on a statistically significant result, the wrong-sign probability would be [TYPE_S]% and the expected magnitude exaggeration would be [TYPE_M]x on the [working/log] scale. These are repeated-study operating characteristics under the assumed true effect, not posterior probabilities that the observed result is wrong.
```

If Type S or Type M is undefined:

```text
Because the assumed true effect is at or very near the null, Type S/Type M are undefined or unstable; interpret only the power/type-I-error behavior at the null.
```

## UI behavior

- Add `Copy reviewer text` button.
- Allow selecting the scenario row used for the prose, if easy.
- Keep the table below the plot or in the summary area; avoid cluttering the main plot.

## Tests

Add tests for:

1. Scenario table includes null, estimate-as-truth, thresholds, and custom true effects when supplied.
2. Duplicate scenario values are deduplicated.
3. Estimate-as-truth row includes optimistic/circular warning.
4. Ratio-scale note appears for odds ratio/risk ratio/hazard ratio.
5. Copy text contains alpha, assumed true effect, power, Type S, Type M, and “not posterior probabilities.”
6. Near-null scenario text handles undefined Type S/M.

## Acceptance criteria

- Scenario table renders for valid design-enabled responses.
- Copyable text is reviewer/grant-critique ready.
- Wording avoids causal/decision overclaiming.
- Existing observed summaries remain unchanged when design is disabled.
