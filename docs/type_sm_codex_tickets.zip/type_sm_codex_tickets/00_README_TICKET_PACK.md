# Type S / Type M Design Calibration: Codex Ticket Pack

## Purpose

This ticket pack turns the confidence-curve / p-value-curve app into a two-layer interpretation tool:

1. **Observed-evidence layer**: the current confidence curve, compatibility curve, and normalized Wald relative-likelihood curve from a reported estimate and 95% CI.
2. **Design-reliability layer**: power, Type S probability, Type M exaggeration, and observed exaggeration across candidate **true** effect sizes, under the same one-parameter Wald model and reconstructed SE.

The design layer must be clearly labeled as a repeated-study/design calculation. It is **not** a posterior probability that the observed result is wrong, and it is **not** directly interchangeable with the observed p-value curve, confidence curve, or relative-likelihood curve.

## How to use these tickets

Give Codex one ticket at a time. Use this order unless you intentionally want a smaller MVP:

1. `01_design_metrics_numerical_core.md`
2. `02_response_contract_and_csv_export.md`
3. `03_ui_inputs_and_state.md`
4. `04_design_visualization_panel.md`
5. `05_scenario_table_and_reviewer_summary.md`
6. `06_precision_scenarios_and_inverse_design_targets.md`
7. `07_tests_docs_and_verification.md`
8. `08_future_extensibility_selection_rules.md`

Tickets 01-05 are the recommended MVP. Ticket 06 is a higher-value extension for grant/sample-size critique. Ticket 08 is intentionally future-facing and should not be mixed into the MVP unless the earlier tickets are stable.

## Repository assumptions

Assume the current repository has this architecture:

- `src/confcurve/` is the numerical source of truth.
- `web/` is the static GitHub Pages app.
- `web/assets/py/confcurve/` is staged Python for Pyodide and should not be hand-edited.
- `web/assets/app.js` handles browser entrypoint/event wiring.
- `web/assets/renderers.js` handles summaries, CSV, captions, warnings, and HTML rendering.
- `web/assets/plot.js` and `web/assets/plot-helpers.js` handle Plotly rendering/export.
- `tests/` includes unit, integration/property, and Playwright E2E tests.

Before making nontrivial edits, Codex should read `AGENTS.md`, `README.md`, `docs/DECISIONS.md`, and any relevant `.agents/skills/` guidance. Follow the repo rule that browser-facing Python changes must be staged with `make stage-web` rather than by editing `web/assets/py/confcurve/` directly.

## Cross-cutting scientific guardrails

- Compute ratio-measure design quantities on the **log working scale**. Display natural ratio values only as labels/summaries.
- Type M is an exaggeration ratio on the working-scale distance from the null, not an inflation of the natural-scale odds ratio/risk ratio/hazard ratio.
- Type S and Type M are functions of an assumed true effect, SE, alpha, and selection rule.
- Observed p-values/CIs/LRs describe compatibility of candidate effect values with observed data. Type S/M describe what would happen across repeated studies **if a candidate effect were true**.
- Near the null, Type M is undefined or unstable because the denominator approaches zero. Return `None`/blank in JSON/UI, not `NaN` or `Infinity`.
- Use terms such as “candidate true effect,” “assumed true effect,” and “design calibration.” Avoid saying “probability this result is wrong.”
- Do not change the existing observed confidence/likelihood reconstruction formulas except where explicitly required.

## Default model for MVP

For the MVP, support only:

- One-parameter normal/Wald model.
- Two-sided selection rule: `p < alpha` against the user-specified null.
- Default `alpha = 0.05`.
- Design metrics computed using the CI-reconstructed working-scale SE.

Future selection rules are reserved for Ticket 08.

## Verification commands

At minimum after each implementation ticket:

```bash
uv sync --locked
make stage-web
make fmt-check
make lint
make test
```

For browser/UI tickets:

```bash
make e2e
make verify
```

## Recommended PR structure

Each ticket should be a separate PR or commit series. Each final Codex report should include:

- changed files,
- numerical assumptions,
- user-visible behavior changes,
- verification commands run,
- any remaining risks or deliberately deferred items.
