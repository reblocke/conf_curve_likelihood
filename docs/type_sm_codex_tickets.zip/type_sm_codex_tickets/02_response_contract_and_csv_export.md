# Ticket 02 — Extend the Python/browser contract with optional design metrics and CSV columns

## Goal

Expose the numerical design metrics from Ticket 01 through `compute_curves()` without breaking the existing observed confidence/likelihood payload. Add CSV export support for design-metric columns when design calibration is enabled.

## Dependencies

Requires Ticket 01.

## Files likely involved

- `src/confcurve/models.py`
- `src/confcurve/web_contract.py`
- `web/assets/renderers.js`
- tests under `tests/`
- staged browser package after implementation: `make stage-web`

## Contract design

Add an optional or nullable `design` block to the existing `CurveResponse`. Do not rename or remove existing `meta`, `summary`, `warnings`, or `grid` fields.

Preferred backwards-compatible shape:

```python
class CurveResponse(TypedDict):
    meta: MetaPayload
    summary: SummaryPayload
    warnings: list[str]
    grid: GridPayload
    design: DesignPayload | None
```

If the existing typing structure makes a nullable field awkward, a `total=False` optional key is acceptable, but the browser code must tolerate both missing and `null` design blocks.

## Request fields

Extend `CurveRequest` with design-related fields. Suggested names:

```python
design_enabled: bool
design_alpha: float
design_selection_rule: str  # MVP only: "two_sided_p_lt_alpha"
design_true_effects: list[float]  # user-supplied MCID/external values, display scale
design_plausible_range_lower: float | None  # display scale; marker/shading only in MVP
design_plausible_range_upper: float | None
```

For the MVP, compute design metrics on the same x-grid used for the observed curve. Treat the plausible true-effect range as metadata for display/shading/filtering, not as something that changes the observed reconstruction or the x-grid. This avoids silently changing observed-data displays based on design-analysis inputs.

## Design payload shape

Suggested payload:

```python
class DesignConfigPayload(TypedDict):
    enabled: bool
    alpha: float
    selection_rule: str
    se_working: float
    null_working: float
    estimate_working: float
    near_null_delta: float
    type_m_scale_note: str

class DesignGridPayload(TypedDict):
    true_effect_display: list[float]
    true_effect_working: list[float]
    delta: list[float]
    power: list[float]
    type_s: list[float | None]
    type_m: list[float | None]
    expected_selected_abs_z: list[float | None]
    observed_exaggeration: list[float | None]

class DesignScenarioPayload(TypedDict):
    label: str
    source: str  # e.g., "null", "estimate", "threshold", "custom_true_effect"
    true_effect_display: float
    true_effect_working: float
    delta: float
    power: float
    type_s: float | None
    type_m: float | None
    observed_exaggeration: float | None
    note: str | None

class DesignPayload(TypedDict):
    config: DesignConfigPayload
    grid: DesignGridPayload
    scenarios: list[DesignScenarioPayload]
    warnings: list[str]
```

The scenario list can be minimally populated in this ticket and enriched in Ticket 05. At minimum include scenario objects for user-supplied `design_true_effects` if present.

## JSON-safety rules

- Convert undefined Type S/M/observed-exaggeration values to `None` before returning from `compute_curves()`.
- Do not emit `NaN`, `Infinity`, or `-Infinity` in the JSON-like payload.
- Preserve existing finite-floating-point warnings for observed curve values.

## Ratio-scale behavior

For ratio measures, incoming `design_true_effects` and plausible design ranges are display-scale values and must be converted to the log working scale with existing helpers. The payload should display natural-scale values but label Type M as a working-scale exaggeration ratio.

## CSV export

Update CSV generation in `web/assets/renderers.js` so that when `response.design` is present and enabled, exported rows include design columns aligned to the existing plotted x-grid:

```text
design_delta_if_true
design_power_if_true
design_type_s_if_true
design_type_m_if_true
design_expected_selected_abs_z_if_true
design_observed_exaggeration_if_true
```

When design is disabled, either omit these columns or include them blank. Prefer omitting them when disabled to keep existing exports stable.

## Tests

Add/update tests for:

1. `compute_curves()` returns `design is None` or missing when design is disabled.
2. `compute_curves()` returns a populated design block when enabled.
3. Grid arrays in `design.grid` have the same length as `grid.effect_display` in the MVP.
4. JSON serialization succeeds without NaN/Infinity.
5. Ratio-scale design true effects are converted correctly to working scale.
6. CSV export includes design columns only when design is enabled.

## Acceptance criteria

- Existing payload consumers still work.
- Browser can render existing app with design disabled.
- Design-enabled responses are JSON-safe.
- CSV export contains aligned design columns when enabled.
- `make test` passes; browser-facing package is staged before any E2E work.
